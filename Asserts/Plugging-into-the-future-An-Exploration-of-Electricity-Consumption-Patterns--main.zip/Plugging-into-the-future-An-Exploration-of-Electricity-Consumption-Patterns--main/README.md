# Plugging-into-the-future-An-Exploration-of-Electricity-Consumption-Patterns-
